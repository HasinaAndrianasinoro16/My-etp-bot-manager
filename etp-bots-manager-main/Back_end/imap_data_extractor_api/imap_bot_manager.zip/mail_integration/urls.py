from django.urls import path
from .views import MailIntegrationView

urlpatterns = [
    # GET  /mail/              → list()   emails filtres pagines
    path('', MailIntegrationView.as_view({'get': 'list'}), name='mail-list'),

    # GET  /mail/<id>/         → retrieve() un email filtre
    path('<str:pk>/', MailIntegrationView.as_view({'get': 'retrieve'}), name='mail-detail'),

    # GET  /mail/start/        → start_outlook_auth()
    path('start/', MailIntegrationView.as_view({'get': 'start_outlook_auth'}), name='mail-start'),

    # GET  /mail/callback/     → outlook_callback()
    path('callback/', MailIntegrationView.as_view({'get': 'outlook_callback'}), name='mail-callback'),

    # GET  /mail/status/       → outlook_status()
    path('status/', MailIntegrationView.as_view({'get': 'outlook_status'}), name='mail-status'),

    # POST /mail/disconnect/   → disconnect_outlook()
    path('disconnect/', MailIntegrationView.as_view({'post': 'disconnect_outlook'}), name='mail-disconnect'),

    # POST /mail/webhook/      → outlook_webhook()
    path('webhook/', MailIntegrationView.as_view({'post': 'outlook_webhook'}), name='mail-webhook'),

    # GET  /mail/test-connection/ → test_outlook_connection()
    path('test-connection/', MailIntegrationView.as_view({'get': 'test_outlook_connection'}), name='mail-test'),
]