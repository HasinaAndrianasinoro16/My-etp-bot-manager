"""
bots/service.py

BotService — gestion du cycle de vie des bots.

Flux d'activation (OAuth2) :
  1. L'utilisateur connecte son Outlook une seule fois via /mail/start/ -> /mail/callback/
  2. Le token est stocke dans MongoDB (collection outlook_token)
  3. activate_bot() recupere ce token et demarre le thread bot
  4. Le bot lit les emails via Microsoft Graph API
"""

import logging
import threading
from datetime import datetime, timedelta
from typing import Dict

from rest_framework_simplejwt.tokens import AccessToken

from configurations.services import mongo_service
from task.services import task_service
from imap_data_extractor_api.utils import get_next_sequence_value
from .serializer import BotSerializer, BotArchiveSerializer

logger = logging.getLogger(__name__)


class BotService:

    def __init__(self):
        self.collection     = mongo_service.get_collection("bot")
        self.archive        = mongo_service.get_collection("bot_archive")
        self.outlook_tokens = mongo_service.get_collection("outlook_token")

    # ========================= BASIC =========================

    def get_by_id(self, bot_id):
        return self.collection.find_one({"bot_id": bot_id})

    def generate_bot_token(self, bot_id, user_id):
        token = AccessToken()
        token.set_exp(lifetime=timedelta(days=30))
        token["is_bot"]           = True
        token["bot_id"]           = bot_id
        token["assigned_user_id"] = user_id
        return str(token)

    def is_bot_owner(self, bot_id, user_id, role):
        if role == "admin":
            return True
        return self.collection.find_one({
            "bot_id":           bot_id,
            "assigned_user_id": user_id,
        }) is not None

    # ========================= STATUS =========================

    def update_status(self, bot_id, status):
        self.collection.update_one(
            {"bot_id": bot_id},
            {"$set": {"status": status}},
        )

    # ========================= BOT LIFECYCLE =========================

    def activate_bot(self, bot_id: int, user_id: int) -> Dict:
        """
        Active un bot en utilisant le token OAuth2 Outlook stocke en MongoDB.
        """
        # 1. Verifications metier
        bot = self.get_by_id(bot_id)
        if not bot:
            return {"error": "Bot introuvable", "code": "BOT_NOT_FOUND"}

        status = bot.get("status")
        if status == 1:
            return {"error": "Bot deja actif", "code": "ALREADY_ACTIVE"}
        if status == 2:
            return {"error": "Bot en pause", "code": "PAUSED"}

        # 2. Verifier que Outlook est connecte
        outlook_doc = self.outlook_tokens.find_one({"user_id": user_id})
        if not outlook_doc or not outlook_doc.get("connected"):
            logger.warning("Outlook non connecte pour user_id=%s", user_id)
            return {
                "error": "Votre boite Outlook n'est pas connectee. "
                         "Cliquez sur 'Connecter Outlook' dans le dashboard.",
                "code": "OUTLOOK_NOT_CONNECTED",
            }

        # 3. Marquer actif + creer tache
        self.update_status(bot_id, 1)
        task = task_service.create_task(bot_id, user_id)

        # 4. Demarrer le thread bot
        runner = BotGraphRunner(bot_id=bot_id, user_id=user_id)

        def run_and_cleanup():
            try:
                runner.run()
            except Exception as exc:
                logger.exception("Bot %s plante : %s", bot_id, exc)
            finally:
                self.update_status(bot_id, 0)
                logger.info("Bot %s arrete, statut remis a 0", bot_id)

        thread = threading.Thread(target=run_and_cleanup, daemon=True)
        thread.start()
        logger.info("Bot %s demarre (user_id=%s)", bot_id, user_id)

        return {"success": True, "task_id": task.get("id")}

    # ── autres etats ──────────────────────────────────────────────────────────

    def start_bot(self, bot_id):
        self.update_status(bot_id, 1)

    def pause_bot(self, bot_id):
        self.update_status(bot_id, 2)  # 2 = En pause

    def stop_bot(self, bot_id):
        self.update_status(bot_id, 0)  # 0 = Arrêté
        task_service.stop_task(bot_id)

    def delete_bot(self, bot_id, user_id):
        now = datetime.utcnow()
        self.update_status(bot_id, 3)
        bot = self.get_by_id(bot_id)
        archive = {
            "bot_archive_id": get_next_sequence_value("bot_archive_id"),
            "bot_id":         bot_id,
            "bot":            BotSerializer(bot).data,
            "deleted_at":     now,
            "deleted_by":     user_id,
        }
        self.archive.insert_one(archive)


bot_service = BotService()


# ═══════════════════════════════════════════════════════════════════
# RUNNER — Thread de polling Microsoft Graph pour un bot actif
# ═══════════════════════════════════════════════════════════════════

class BotGraphRunner:
    """
    Poll l'INBOX toutes les POLL_INTERVAL secondes via Microsoft Graph API.
    Utilise le token OAuth2 stocke en MongoDB (auto-refresh via outlook_service).
    """

    POLL_INTERVAL = 30

    def __init__(self, bot_id: int, user_id: int):
        self.bot_id     = bot_id
        self.user_id    = user_id
        self._stop_flag = threading.Event()

    def stop(self):
        self._stop_flag.set()

    def run(self) -> None:
        from mail_integration.services import outlook_service, OutlookNotConnectedException
        from mail_integration.tasks import process_graph_message
        from configurations.services import mongo_service

        # ✅ Charger les IDs déjà filtrés par CE bot depuis filtered_emails
        # Un email dans raw_imap_emails mais pas dans filtered_emails sera retraité
        filtered_collection = mongo_service.get_collection("filtered_emails")
        seen_ids: set = set(
            doc["imap_uid"]
            for doc in filtered_collection.find(
                {"imap_uid": {"$exists": True}, "bot_id": self.bot_id},
                {"imap_uid": 1, "_id": 0}
            )
        )

        logger.info(
            "BotGraphRunner demarre | bot_id=%s | user_id=%s | %d messages deja connus",
            self.bot_id, self.user_id, len(seen_ids)
        )

        while not self._stop_flag.is_set():
            try:
                data = outlook_service.list_messages(self.user_id, top=100)
                messages = data.get("value", [])

                for msg in messages:
                    message_id = msg.get("id")
                    if not message_id or message_id in seen_ids:
                        continue

                    # ✅ Bug 1 corrigé : un seul appel (suppression du doublon)
                    logger.info("ENVOI TACHE | message_id=%s | bot_id=%s", message_id, self.bot_id)
                    process_graph_message.delay(
                        user_id=self.user_id,
                        message_id=message_id,
                        bot_id=self.bot_id,
                    )
                    seen_ids.add(message_id)
                    logger.info("Nouveau message | id=%s | bot_id=%s", message_id, self.bot_id)

                self._stop_flag.wait(timeout=self.POLL_INTERVAL)

            except OutlookNotConnectedException as exc:
                logger.error("Token Outlook expire bot_id=%s : %s", self.bot_id, exc)
                break
            except Exception as exc:
                logger.exception("Erreur BotGraphRunner bot_id=%s : %s", self.bot_id, exc)
                self._stop_flag.wait(timeout=self.POLL_INTERVAL)

        logger.info("BotGraphRunner arrete | bot_id=%s", self.bot_id)